package edu.ubc.mirrors;

public interface ConstructorMirrorExitEvent extends MirrorEvent {

    public ConstructorMirror constructor();
}
