package edu.ubc.mirrors;

public interface MirrorEvent {

    MirrorEventRequest request();
}
