package edu.ubc.mirrors.test;

public class Supertype {

    
    public void foo(Object o) {
        
    }
    
    
}
