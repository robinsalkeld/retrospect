package edu.ubc.mirrors.test;

public class SubtypeTest extends Supertype {

    public void main(String[] args) {
        foo(args);
    }
}
