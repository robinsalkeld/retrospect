package edu.ubc.mirrors.test;

public class JREOnly {

    public static void main(String[] args) {
        while (true) {
            foo();
        }
    }
    
    private static void foo() {
        
    }
}
