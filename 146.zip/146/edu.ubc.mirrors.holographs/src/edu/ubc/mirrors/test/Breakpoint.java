package edu.ubc.mirrors.test;

public class Breakpoint {

    public static void bp() {
        
    }
    
}
