package edu.ubc.mirrors;

public interface ClassMirrorPrepareRequest extends MirrorEventRequest {

}
