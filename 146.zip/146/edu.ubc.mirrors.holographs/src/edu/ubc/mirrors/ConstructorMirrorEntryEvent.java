package edu.ubc.mirrors;

public interface ConstructorMirrorEntryEvent extends MirrorEvent {

    public ConstructorMirror constructor();
}
