package edu.ubc.mirrors.holographs;

public class ArrayClassHolograph {

}
