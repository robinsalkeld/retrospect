package edu.ubc.mirrors.holographs;

/**
 * Marker interface for new instances created within holographic execution. 
 * @author Robin Salkeld
 */
public interface NewHolographInstance {

}
