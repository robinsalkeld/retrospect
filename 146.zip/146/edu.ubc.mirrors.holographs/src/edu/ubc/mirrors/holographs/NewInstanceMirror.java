package edu.ubc.mirrors.holographs;

public interface NewInstanceMirror {

}
