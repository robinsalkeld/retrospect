package edu.ubc.mirrors;

public interface ArrayMirror extends ObjectMirror {
    public int length();
}
