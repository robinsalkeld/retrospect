package edu.ubc.mirrors;

public interface FieldMirrorSetRequest extends MirrorEventRequest {

}
