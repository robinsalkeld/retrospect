package edu.ubc.mirrors;

public interface ClassMirrorPrepareEvent extends MirrorEvent {

    public ClassMirror classMirror();
}
