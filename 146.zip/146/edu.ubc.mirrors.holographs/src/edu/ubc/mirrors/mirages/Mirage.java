package edu.ubc.mirrors.mirages;

import edu.ubc.mirrors.ObjectMirror;

public interface Mirage {

    public ObjectMirror getMirror();
}
