package edu.ubc.mirrors;

public interface ThreadMirrorDeathRequest extends MirrorEventRequest {

}
