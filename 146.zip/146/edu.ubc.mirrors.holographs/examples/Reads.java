package examples;

public @interface Reads {
    String[] value();
}
