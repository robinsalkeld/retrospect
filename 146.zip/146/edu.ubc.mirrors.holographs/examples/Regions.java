package examples;

public @interface Regions {
    String[] value();
}
