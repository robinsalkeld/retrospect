package examples;

public @interface Writes {
    String[] value();
}
